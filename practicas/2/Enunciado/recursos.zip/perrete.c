/**
 * @file perrete.c
 *
 * @brief TODO
 *
 * @author  TODO
 * @version TODO
 *
 **/

// TODO: Completa con las dependencias del programa

int main (void) {
    // Parte declarativa de datos
    int windows_size = 400;
    string window_title = ""; // TODO: Completa con tus iniciales

    // Creamos el dibujo
    crea_ventana (window_title, windows_size, windows_size);

    // TODO: Completa con el dibujo de cabeza, cuerpo, patas y cola

    // TODO: Pinta el dibujo y espera a que se cierre la ventana

    // TODO: Destruimos el dibujo
    destruye_ventana();

    return 0;
}
