/**
 * @file hola_grafico.c
 *
 * @brief Output Hello World in a graphical window
 *
 * @author  Intro_SW
 * @version 1.0
 *
 **/

#include "dibujo.h"

int main (void) {

    // Creamos el dibujo
    crea_ventana ("Hola gráfico con la librería dibujo", 400, 400);

    // Creamos un texto en el dibujo
    crea_texto (10, 50, "Hola mundo", "negro", 40);
    // Pintamos el dibujo y esperamos a que se cierre la ventana
    pinta_y_espera();

    // Destruimos el dibujo
    destruye_ventana();

    return 0;
}
